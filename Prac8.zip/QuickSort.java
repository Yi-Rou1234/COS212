public class QuickSort <T extends Comparable<T>> extends Sort<T> {
    @Override
    @SuppressWarnings("unchecked")
    public Comparable<T>[] sort(Comparable<T>[] arr) {
        printArr(arr);
        //Add code below this line
        recSort(arr, 0, arr.length - 1);
        return arr;
    }

    @SuppressWarnings("unchecked")
    private Comparable<T>[] recSort(Comparable<T>[] arr, Comparable<T>[] resultingArr){
        printArr(arr);
        //Add code below this line
        if (arr.length > 1) {
            Comparable<T> pivot = arr[getPivotPoint(arr)];
            int size1 = 0;
            int size2 = 0;

            for (Comparable<T> el : arr) {
                if (el.compareTo((T) pivot) <= 0)
                    size1++;
                else
                    size2++;
            }

            Comparable<T>[] data1 = (Comparable<T>[]) new Comparable[size1];
            Comparable<T>[] data2 = (Comparable<T>[]) new Comparable[size2];
            int index1 = 0;
            int index2 = 0;

            for (Comparable<T> el : arr) {
                if (el.compareTo((T) pivot) <= 0)
                    data1[index1++] = el;
                else
                    data2[index2++] = el;
            }

            recSort(data1, resultingArr);
            recSort(data2, resultingArr);

            int index = 0;
            for (Comparable<T> el : data1)
                resultingArr[index++] = el;

            for (Comparable<T> el : data2)
                resultingArr[index++] = el;
        } else if (arr.length == 1) {
            resultingArr[0] = arr[0];
        }
        return resultingArr;
    }

    private int getPivotPoint(Comparable<T>[] arr){
        if(arr == null || arr.length == 0)
            return 0;

        if(arr.length % 2 == 0)
            return (int)Math.floor(arr.length/2)-1;
        else 
            return (int)Math.floor(arr.length/2);
    }

    private void swap(Comparable<T>[] arr, int i, int j) {
        Comparable<T> temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    private void recSort(Comparable<T>[] arr, int first, int last) {
        if (first < last) {
            printArr(arr);
            
            int pivotIndex = partition(arr, first, last);
            recSort(arr, first, pivotIndex - 1);
            recSort(arr, pivotIndex + 1, last);
        }
    }

    private int partition(Comparable<T>[] arr, int first, int last) {
        Comparable<T> pivot = arr[first];
        int lower = first + 1;
        int upper = last;

        while (lower <= upper) {
            while (lower <= upper && arr[lower].compareTo((T) pivot) < 0)
                lower++;
            while (lower <= upper && arr[upper].compareTo((T) pivot) > 0)
                upper--;
            
            if (lower < upper) {
                swap(arr, lower, upper);
                lower++;
                upper--;
            }
        }

        swap(arr, first, upper);

        return upper;
    }
}
