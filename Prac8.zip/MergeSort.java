public class MergeSort <T extends Comparable<T>> extends Sort<T> {
    @Override
    @SuppressWarnings("unchecked")
    public Comparable<T>[] sort(Comparable<T>[] arr) {
        //Hint This function can be implemented as a one liner consisting of a return and a function call
        return mergeSort(arr);
    }

    @SuppressWarnings("unchecked")
    private Comparable<T>[] mergeSort(Comparable<T>[] arr){
        //Do not change the position of this function.
        printArr(arr);
        //Add any code below

        if (arr.length <= 1){
            return arr;
        }
        else {
            int midPt = getMidPoint(0, arr.length);
            Comparable<T>[] leftSide = (Comparable<T>[]) new Comparable[midPt];
            Comparable<T>[] rightSide = (Comparable<T>[]) new Comparable[arr.length - midPt];
            
            for (int i = 0 ; i < midPt ; i++ ){
                leftSide[i] = arr[i];
            }
            
            int index = 0;
            for (int j = midPt; j < arr.length ; j++){
                rightSide[index] = arr[j];
                index++;
            }

            leftSide = mergeSort(leftSide);
            rightSide = mergeSort(rightSide);
            return merge( leftSide, rightSide);
        }
    }

    @SuppressWarnings("unchecked")
    private Comparable<T>[] merge(Comparable<T>[] arr1, Comparable<T>[] arr2) {
        int index1 = 0;
        int index2 = 0;
        int index3 = 0;

        Comparable<T>[] temp = (Comparable<T>[]) new Comparable[ arr1.length + arr2.length];
    
        while (index2 < arr1.length && index3 < arr2.length) {
            if (arr1[index2].compareTo((T) arr2[index3]) < 0) {
                temp[index1++] = arr1[index2++];
            } else {
                temp[index1++] = arr2[index3++];
            }
        }
    
        while (index2 < arr1.length ) {
            temp[index1++] = arr1[index2++];
        }
    
        while (index3 < arr2.length) {
            temp[index1++] = arr2[index3++];
        }

        return temp;
    }
    

    private int getMidPoint(int first, int last){
        return (int)Math.floor((first+last)/2);
    }
    
}
