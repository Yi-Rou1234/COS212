public class CountSort<T extends Comparable<T>> extends Sort<T> {
    
    @Override
    @SuppressWarnings("unchecked")
    public Comparable<T>[] sort(Comparable<T>[] arr) {
        //Do not alter given code nor add code above
        int[] count = formCountArr(arr);
        printArr(arr, count);
        int[] sumCount = sumCount(count);
        printArr(arr, sumCount);
        Comparable<T>[] res = new Comparable[arr.length]; //This array needs to be populated with the final result
        //Add code below this
        for (int i = arr.length - 1; i >= 0; i--) {
            res[sumCount[arr[i].hashCode()]-1] = arr[i];
            sumCount[arr[i].hashCode()]--;
        }
        //Do not change the statement below
        printArr(res, sumCount);
        //Ensure only return statement is below this
        return res;
    }

    private static <T> int[] formCountArr(Comparable<T>[] arr) {
        int size = countArraySize(arr);
        int[] countArr = new int[size + 1];
    
        for (Comparable<T> element : arr) {
            int hashCode = element.hashCode();
            if (hashCode >= 0 && hashCode <= size) {
                countArr[hashCode]++;
            }
        }
    
        
    
        return countArr;
    }

    private static int[] sumCount(int[] countArr) {
        //int[] result = new int[countArr.length];
        //result[0] = countArr[0];
        for (int i = 1; i < countArr.length; i++) {
            countArr[i] = countArr[i - 1] + countArr[i];
        }
        return countArr;
    }
    

    private static <T> int countArraySize(Comparable<T>[] arr) {
        int size = 0;
        for (Comparable<T> element : arr) {
            int hashCode = element.hashCode();
            if (hashCode > size) {
                size = hashCode;
            }
        }
        return size;
    }
    

    private void printArr(Comparable<T>[] arr, int[] count){
        if(arr == null || count == null)
            System.out.println("NULL ARRAYS");

        String res = "[";
        for(Comparable<T> t: arr){
            res += t + "{" + count[t.hashCode()] + "},";
        }
        if(res.length() > 0){
            res = res.substring(0, res.length()-1);
        }
        res += "]";
        System.out.println(res);
    }


}
