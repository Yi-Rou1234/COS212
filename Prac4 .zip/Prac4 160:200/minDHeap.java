@SuppressWarnings("unchecked")
public class minDHeap<T extends Comparable<T>> {
    private int d;
    private T[] nodes;

    @Override
    public String toString() {
        if (nodes.length == 0) {
            return "";
        }

        return "[" + nodes[0] + "]\n" + toStringRec(0, "");
    }

    public String toStringRec(int i, String pre) {
        if (i >= nodes.length) {
            return "";
        }
        String res = "";
        for (int k = 0; k < d; k++) {
            int c = d * i + k + 1;
            if (c < nodes.length) {
                if (k == d - 1 || c + 1 >= nodes.length) {
                    res += pre + "└── " + "[" + nodes[c] + "]\n" + toStringRec(c, pre + "    ");
                } else {
                    res += pre + "├── " + "[" + nodes[c] + "]\n" + toStringRec(c, pre + "│   ");
                }
            }
        }
        return res;
    }

    public T[] getNodes() {
        return nodes;
    }

    /*
     * Don't change anything above this line
     */

    public minDHeap(int d) {
        this.d = d;
        nodes =(T[])new Comparable[0];
    }

    public void insert(T val) {
        // if (!isEmpty()){
        int size = nodes.length;
        int parentIndex = parent(size);
        T[]newNodes =(T[]) new Comparable[nodes.length+1];
        
        for (int m=0; m< size; m++){
            newNodes[m] = nodes[m];
        }

        newNodes[size] = val;
        nodes = newNodes;
        while (size >0 && nodes[size].compareTo(nodes[parent(size)])<0) {
            swap(size, parent(size));
            nodes = newNodes;
            size = parentIndex;
            parentIndex = parent(size);
        }
    // }
    }

    public void remove(T val) {
        int size = Find(val);
        if(size==-1){
            return;
        }

        nodes[size] = nodes[size--];
        T[] value =(T[]) new Comparable[nodes.length-1];
        for (int i = 0; i<value.length ;i++){
            value[i] = nodes[i];
        }
        nodes= value;

        minHeap(size);
    }

    public void changeD(int newD) {
        this.d = newD;
        // int i = (nodes.length - 2) / 2;

        // while (i >= 0) {
        // int p = i;
        // while (p <= (nodes.length - 2) / 2) {
        //     int maxChild = 2 * p + 1;
        //     if (maxChild < nodes.length - 1 && nodes[maxChild].compareTo(nodes[maxChild + 1])<0) {
        //         maxChild++;
        //     }
        //     if (nodes[p].compareTo(nodes[maxChild])<0) {
        //         T temp = nodes[p];
        //         nodes[p] = nodes[maxChild];
        //         nodes[maxChild] = temp;
        //     } else {
        //         break;
        //     }
        //     p = maxChild;
        // }
        // i--;
        // }
        for (int j = parent(nodes.length-1); j>=0; j--){
            int childI = smallestChild(j);
            while (childI != -1 && nodes[childI].compareTo(nodes[j])<0){
                swap(j, childI);
                j = childI;
                childI = smallestChild(j);
            }
        }
    }

    public T min(int i) {
        if (nodes.length==0 || i >= nodes.length || i < 0) {
            return null;
        }
        
        int start = leftChild(i);
        int end = Math.min(start+d,nodes.length);
        T minVal = nodes[i];
        
        // if (left < nodes.length && nodes[left].compareTo(minVal) < 0) {
        //     minVal = nodes[left];
        // }
        
        // if (right < nodes.length && nodes[right].compareTo(minVal) < 0) {
        //     minVal = nodes[right];
        // }
        for(int j = start; j<end; j++){
            if(nodes[j].compareTo(minVal)< 0){
                minVal= nodes[j];
            }
        }
        return minVal;
    }

    public T max(int i) {
            if (i >= nodes.length || i < 0) {
                return null;
            }
            
            int start = leftChild(i);
            int end= Math.min(start+d, nodes.length);
            T maxVal = nodes[i];
            
            // if (start < nodes.length && nodes[start].compareTo(maxVal) > 0) {
            //     maxVal = nodes[start];
            // }
            
            // if (right < nodes.length && nodes[right].compareTo(maxVal) > 0) {
            //     maxVal = nodes[right];
            // }
            int k = start;
            while (k< end){
                T childVal =max(k);
                if (childVal!= null && childVal.compareTo(maxVal)>0){
                    maxVal =childVal;
                }
                k++;
            }

            return maxVal;
    }
        

    public String pathToRoot(T val) {
        int index= -1;
        for (int j =0;j <nodes.length;j++){
            if (nodes[j].equals(val)){
                index =j;
                break;
            }
        }
        if (index==-1){
            return "";
        }
        String output = "["+nodes[index]+"]";
        while (index != 0){
            index= parent(index);
            output+= "[" + nodes[index] + "]";
        }
        return output;
    }

    private int parent(int curr){ return (curr-1) /d ;}

    private int leftChild(int pos){return (pos*d) + 1;}

    // private int rightChild(int pos){return (pos*d) + 2;}

    private int Find(T val){
        int found = 0;
        while ( found<nodes.length){
            if (nodes[found] != null && nodes[found].equals(val)){
                return found;
            }
            found++;
        }
        return -1;
    }

    private void swap(int child, int parent){
        T temp;
        temp = nodes[child];
        nodes[child] = nodes[parent];
        nodes[parent] = temp;
    }

    private void minHeap(int pos){
        // if (!(pos > (d / 2))){
        //     int Swap = pos;
        //     if (rightChild(pos) <= d)
        //         Swap = nodes[leftChild(pos)].compareTo(nodes[rightChild(pos)]) < 0?leftChild(pos):rightChild(pos);
        //     else
        //         Swap = leftChild(pos);
            
        //     if (nodes[pos].compareTo(nodes[leftChild(pos)])>0 || nodes[pos].compareTo(nodes[rightChild(pos)]) > 0){
        //         swap(pos,Swap);
        //         minHeap(Swap);
        //     }
        // }
        int parentIndex = parent(pos);
        int childIndex = smallestChild(pos);
        int DuppPos = pos;
        while (pos >0 && nodes[pos].compareTo(nodes[parentIndex])<0){
            swap(pos,parentIndex);
            pos=parentIndex;
            parentIndex = parent(pos);
        }

        while(childIndex != -1 && nodes[childIndex].compareTo(nodes[DuppPos])<0){
            swap(DuppPos, childIndex);
            DuppPos = childIndex;
            childIndex = smallestChild(DuppPos);
        }
    }

    private int smallestChild(int index){
        if (index == -1){
            return -1;
        }
        int size = nodes.length;
        int leftChildIndex=d * index + 1;

        if (leftChildIndex>= size){
            return -1;
        }

        int smallestChildIndex= leftChildIndex;
        int count = 2;
        while (count<= d && leftChildIndex + count - 1<size){
            int nextChildIndex = leftChildIndex + count - 1;
            if (nodes[nextChildIndex].compareTo(nodes[smallestChildIndex]) < 0){
                smallestChildIndex= nextChildIndex;
            }
            count++;
        }
        return smallestChildIndex;
    }
    
}
