public class CountList<T extends Comparable<T>> extends SelfOrderingList<T> {
    @Override
    public SelfOrderingList<T> getBlankList() {
        // TODO: Implement the function
        return new CountList<T>();
    }

    @Override
    public void access(T data) {
        // TODO: Implement the function
        Node<T> current = head;

        while (current != null && !current.data.equals(data)) {
            current = current.next;
        }

        if (current != null) {
            current.accessCount++;
            if (!current.data.equals(head.data)) {
                Node<T> ptr = current.prev;
                while (ptr != null && ptr.accessCount < current.accessCount) {
                    ptr = ptr.prev;
                }

                if (current.prev != null) {
                    current.prev.next = current.next;
                }

                if (current.next != null) {
                    current.next.prev = current.prev;
                }

                if (ptr == null) {
                    current.prev = null;
                    current.next = head;
                    head.prev = current;
                    head = current;
                } else {
                    if (ptr.next == null) {
                        ptr.next = current;
                        current.prev = ptr;
                    } else {
                        ptr.next.prev = current;
                        current.prev = ptr;

                        current.next = ptr.next;
                        ptr.next = current;
                    }
                }
            }
        }
    }
}
