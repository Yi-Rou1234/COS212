public class MoveToFrontList<T extends Comparable<T>> extends SelfOrderingList<T> {
    @Override
    public SelfOrderingList<T> getBlankList() {
        // TODO: Implement the function
        return new MoveToFrontList<T>();
    }

    @Override
    public void access(T data) {
        // TODO: Implement the function
        Node<T> current = head;

        while (current != null && !current.data.equals(data)) {
            current = current.next;
        }

        if (current != null && !current.data.equals(head.data)) {
            if (current.prev != null) {
                current.prev.next = current.next;
            }

            if (current.next != null) {
                current.next.prev = current.prev;
            }

            current.prev = null;
            current.next = head;
            head.prev = current;
            head = current;
        }

    }
}
