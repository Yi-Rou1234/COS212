public class NaturalOrderList<T extends Comparable<T>> extends SelfOrderingList<T> {
    @Override
    public SelfOrderingList<T> getBlankList() {
        // TODO: Implement the function
        return new NaturalOrderList<T>();
    }

    @Override
    public void access(T data) {

    }

    @Override
    public void insert(T data) {
        // TODO: Implement the function
        Node<T> newNode = new Node<T>(data);
        if (head == null || head.data.compareTo(data) < 0) {
            newNode.next = head;
            if (head != null) {
                head.prev = newNode;
            }
            head = newNode;
        } else {
            Node<T> curreNode = head;

            while (curreNode.next != null && curreNode.data.compareTo(data) > 0) {
                curreNode = curreNode.next;
            }

            if (curreNode.next == null && curreNode.data.compareTo(data) > 0) {

                curreNode.next = newNode;
                newNode.prev = curreNode;

            } else {

                newNode.prev = curreNode.prev;
                if (curreNode.prev != null) {
                    curreNode.prev.next = newNode;
                }
                newNode.next = curreNode;
                curreNode.prev = newNode;
            }
        }
    }
}
