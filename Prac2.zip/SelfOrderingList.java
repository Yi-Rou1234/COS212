abstract class SelfOrderingList<T extends Comparable<T>> {
    public Node<T> head = null;

    public void insert(T data) {
        // TODO: Implement the function
        if (head == null) {
            head = new Node<T>(data);
        } else {
            Node<T> curreNode = head;

            while (curreNode.next != null) {
                curreNode = curreNode.next;
            }
            curreNode.next = new Node<T>(data);
            curreNode.next.prev = curreNode;
        }
    }

    public void remove(T data) {
        // TODO: Implement the function
        if (head != null) {
            if (head.data.equals(data)) {
                head = head.next;
                if (head != null) {
                    head.prev = null;
                }
            } else {
                Node<T> curreNode = head;
                while (curreNode != null && !curreNode.data.equals(data)) {
                    curreNode = curreNode.next;
                }

                if (curreNode != null) {
                    curreNode.prev.next = curreNode.next;
                    if (curreNode.next != null) {
                        curreNode.next.prev = curreNode.prev;
                    }
                    curreNode.next = null;
                    curreNode.prev = null;
                }
            }
        }
    }

    public abstract void access(T data);

    public abstract SelfOrderingList<T> getBlankList();
}
