public class IterativeTraverse<T extends Comparable<T>> extends Traverser<T> {
    public IterativeTraverse() {
        // TODO: Implement the function
        list = null;
    };

    public IterativeTraverse(SelfOrderingList<T> list) {
        // TODO: Implement the function
        Node<T> currNode = list.head;
        if (list != null) {
            this.list = list.getBlankList();
            while (currNode != null) {
                this.list.insert(currNode.data);
                currNode = currNode.next;
            }
        }
    }

    @Override
    public SelfOrderingList<T> reverseList() {
        // TODO: Implement the function
        if (list != null) {
            Node<T> currNode = list.head;
            while (currNode != null && currNode.next != null) {
                currNode = currNode.next;
            }
            SelfOrderingList<T> revList = list.getBlankList();
            while (currNode != null) {
                revList.insert(currNode.data);
                currNode = currNode.prev;
            }
            return revList;
        } else {
            return list;
        }
    }

    @Override
    public boolean contains(T data) {
        // TODO: Implement the function
        if (list != null) {
            Node<T> currNode = list.head;
            while (currNode != null) {
                if (currNode.data.equals(data)) {
                    return true;
                }
                currNode = currNode.next;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        // TODO: Implement the function
        String str = "";
        if (list != null) {
            Node<T> currNode = list.head;

            while (currNode != null) {
                str += "->" + currNode.toString();
                currNode = currNode.next;
            }
        }
        return str;
    }

    @Override
    public Node<T> get(int pos) {
        // TODO: Implement the function
        Node<T> currNode = null;
        if (list != null) {
            currNode = list.head;
            int index = 0;
            while (currNode != null && pos != index) {
                index++;
                currNode = currNode.next;
            }
        }
        return currNode;
    }

    @Override
    public Node<T> find(T data) {
        // TODO: Implement the function
        Node<T> currNode = null;
        if (list != null) {
            currNode = list.head;
            while (currNode != null && !currNode.data.equals(data)) {
                currNode = currNode.next;
            }
        }
        return currNode;
    }

    @Override
    public int size() {
        // TODO: Implement the function
        int index = 0;
        if (list != null) {
            Node<T> currNode = list.head;
            while (currNode != null) {
                index++;
                currNode = currNode.next;
            }
        }
        return index;
    }

    @Override
    public SelfOrderingList<T> clone(SelfOrderingList<T> otherList) {
        // TODO: Implement the function
        SelfOrderingList<T> clone = null;
        if (otherList != null) {
            clone = new MoveToFrontList<T>();
            Node<T> currNode = otherList.head;
            while (currNode != null) {
                clone.insert(currNode.data);
                currNode = currNode.next;
            }
            currNode = clone.head;
            clone = otherList.getBlankList();
            clone.head = currNode;
        }
        return clone;
    }
}
