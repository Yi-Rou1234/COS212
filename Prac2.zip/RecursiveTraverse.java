public class RecursiveTraverse<T extends Comparable<T>> extends Traverser<T> {
    public RecursiveTraverse() {
        // TODO: Implement the function
        list = null;
    }

    public RecursiveTraverse(SelfOrderingList<T> list) {
        // TODO: Implement the function
        if (list != null) {
            this.list = list.getBlankList();
            recursiveTraverse(list.head);
        }
    }

    @Override
    public SelfOrderingList<T> reverseList() {
        // TODO: Implement the function
        if (list != null) {
            SelfOrderingList<T> revList = list.getBlankList();
            reverseList(list.head, revList);
            return revList;
        }
        return null;
    }

    @Override
    public boolean contains(T data) {
        // TODO: Implement the function
        if (list != null)
            return contains(data, list.head);
        return false;
    }

    @Override
    public String toString() {
        // TODO: Implement the function
        if (list != null) {
            return recursiveString("", list.head);
        }
        return "";
    }

    @Override
    public Node<T> get(int pos) {
        // TODO: Implement the function
        if (list != null) {
            return get(pos, 0, list.head);
        }
        return null;
    }

    @Override
    public Node<T> find(T data) {
        // TODO: Implement the function
        if (list != null) {
            return find(data, list.head);
        }
        return null;
    }

    @Override
    public int size() {
        // TODO: Implement the function
        if (list != null) {
            return size(0, list.head);
        }
        return 0;
    }

    @Override
    public SelfOrderingList<T> clone(SelfOrderingList<T> otherList) {
        // TODO: Implement the function
        if (otherList != null) {

            SelfOrderingList<T> clone = new MoveToFrontList<T>();
            clone(clone, list.head);
            Node<T> currNode = clone.head;
            clone = otherList.getBlankList();
            clone.head = currNode;
            return clone;
        }
        return null;
    }

    private void recursiveTraverse(Node<T> currNode) {
        if (currNode == null) {
            return;
        }
        list.insert(currNode.data);
        recursiveTraverse(currNode.next);
    }

    private void reverseList(Node<T> currNode, SelfOrderingList<T> revList) {
        if (currNode == null) {
            return;
        }
        reverseList(currNode.next, revList);
        revList.insert(currNode.data);
    }

    private boolean contains(T data, Node<T> currNode) {
        if (currNode == null) {
            return false;
        } else if (currNode.data.equals(data)) {
            return true;
        } else {
            return contains(data, currNode.next);
        }
    }

    private String recursiveString(String str, Node<T> currNode) {
        if (currNode == null) {
            return str;
        }
        return recursiveString(str + "->" + currNode.toString(), currNode.next);
    }

    private Node<T> get(int pos, int index, Node<T> currNode) {
        if (currNode == null || index == pos) {
            return currNode;
        }
        return get(pos, index + 1, currNode.next);
    }

    private Node<T> find(T data, Node<T> currNode) {
        if (currNode == null || currNode.data.equals((data))) {
            return currNode;
        }
        return find(data, currNode.next);
    }

    private int size(int count, Node<T> currNode) {
        if (currNode == null) {
            return count;
        }
        count++;
        return size(count, currNode.next);
    }

    private void clone(SelfOrderingList<T> otherList, Node<T> currNode) {
        if (currNode == null) {
            return;
        }
        otherList.insert(currNode.data);
        clone(otherList, currNode.next);
    }
}
