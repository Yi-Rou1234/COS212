public class TransposeList<T extends Comparable<T>> extends SelfOrderingList<T> {
    @Override
    public SelfOrderingList<T> getBlankList() {
        // TODO: Implement the function
        return new TransposeList<T>();
    }

    @Override
    public void access(T data) {
        // TODO: Implement the function
        Node<T> current = head;

        while (current != null && !current.data.equals(data)) {
            current = current.next;
        }

        if (current != null && !current.data.equals(head.data)) {

            // current second node on the list
            if (current.prev.prev == null) {

                current.prev.next = current.next;
                if (current.next != null) {
                    current.next.prev = current.prev;
                }

                current.next = current.prev;
                current.prev.prev = current;
                current.prev = null;
                head = current;
            } else {
                current.prev.prev.next = current;
                // work even if it's null
                current.prev.next = current.next;
                // Current next node not null
                if (current.next != null) {
                    current.next.prev = current.prev;
                }

                current.next = current.prev;
                current.prev = current.prev.prev;
                current.next.prev = current;
            }
        }
    }
}
