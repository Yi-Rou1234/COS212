public class Node<T extends Comparable<T>> {

	private Comparable<T>[] keys;
	private Node<T>[] children;
	// custom property
	public boolean isLeaf;
	public int keyTally;
	public Node<T> righNode;
	public Comparable<T> midkey;

	/**
	 * 
	 * @param m
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Node(int m) {
		// TODO - implement Node.Node
		isLeaf = true;
		keys = new Comparable[m - 1];
		children = new Node[m];
		keyTally = 0;
	}

	@Override
	public String toString() {
		String res = "[";
		for (int i = 0; i < keys.length; i++) {
			if (keys[i] != null)
				res += keys[i];
			else
				res += "null";
			res += ",";
		}
		if (res.length() > 1) {
			res = res.substring(0, res.length() - 1);
		}
		return res + "]";
	}

	public Comparable<T>[] getKeys() {
		return keys;
	}

	public Node<T>[] getChildren() {
		return children;
	}

}