@SuppressWarnings({ "unchecked", "rawtypes" })
public class BTree<T extends Comparable<T>> {

	private int m;
	private Node<T> root;

	/**
	 * 
	 * @param m
	 */
	public BTree(int m) {
		// TODO - implement BTree.BTree
		this.m = m;
		root = null;
	}

	/**
	 * 
	 * @param data
	 */
	public Node<T> insert(T data) {
		// TODO - implement BTree.insert
		if (root == null) {
			root = new Node<T>(m);
			Comparable<T>[] keys = root.getKeys();
			keys[0] = data;
			root.keyTally = 1;
			return root;
		} else {
			insert(data, root, null);
			return find(data);
		}
	}

	/**
	 * 
	 * @param data
	 */
	public Node<T> find(T data) {
		// TODO - implement BTree.find
		Node<T> curr = root;
		while (curr != null) {
			Comparable<T>[] currKeys = curr.getKeys();
			for (int currKeysIndex = 0; currKeysIndex < curr.keyTally; currKeysIndex++) {
				if (currKeys[currKeysIndex].equals(data)) {
					return curr;
				} else if (currKeys[currKeysIndex].compareTo(data) > 0) {
					curr = curr.getChildren()[currKeysIndex];
					break;
				} else {
					if (curr.keyTally == currKeysIndex + 1) {
						curr = curr.getChildren()[currKeysIndex + 1];
						break;
					}
				}
			}
		}

		return curr;
	}

	public Node<T>[] nodes() {
		// TODO - implement BTree.leaves
		if (root == null) {
			return null;
		} else {
			int countNumNodes = countNumNodes();
			Node<T>[] currNodes = new Node[countNumNodes];
			nodes(root, currNodes);
			return currNodes;
		}
	}

	public int numKeys() {
		// TODO - implement BTree.numKeys
		if (root == null) {
			return 0;
		}
		return numKeys(root);
	}

	public int countNumNodes() {
		// TODO - implement BTree.countNumLeaves
		if (root == null) {
			return 0;
		}
		return countNumNodes(root);
	}

	// @SuppressWarnings("unchecked")
	public void insert(T data, Node<T> curr, Node<T> prev) {

		if (curr.isLeaf == true) {

			if (curr.keyTally == m - 1) {
				Comparable<T>[] keys = new Comparable[m];
				Comparable<T>[] currKeys = curr.getKeys();

				int keysArrIndex = m - 1;

				while (keysArrIndex > 0) {
					Comparable<T> temp = currKeys[keysArrIndex - 1];
					if (temp.equals(data)) {
						return;
					} else if (temp.compareTo(data) < 0) {
						break;
					} else {
						keys[keysArrIndex] = temp;
					}
					keysArrIndex--;
				}

				keys[keysArrIndex] = data;

				keysArrIndex--;

				while (keysArrIndex >= 0) {
					Comparable<T> temp = currKeys[keysArrIndex];
					keys[keysArrIndex] = temp;
					keysArrIndex--;
				}

				int pos = (int) Math.floor((m - 1) / (double) 2);
				Node<T> righNode = new Node<T>(m);
				Comparable<T>[] rightNodeKeys = righNode.getKeys();

				for (int currKeysIndex = 0; currKeysIndex < currKeys.length; currKeysIndex++) {
					if (currKeysIndex < pos) {
						currKeys[currKeysIndex] = keys[currKeysIndex];
					} else {
						currKeys[currKeysIndex] = null;
						curr.keyTally--;
					}
				}

				for (int rightNodeKeysIndex = 0, posTemp = pos + 1; posTemp < m; posTemp++, rightNodeKeysIndex++) {
					rightNodeKeys[rightNodeKeysIndex] = keys[posTemp];
					righNode.keyTally++;
				}

				if (prev == null) {
					Node<T> newRoot = new Node<T>(m);
					Comparable<T>[] newRootkeys = newRoot.getKeys();
					newRootkeys[0] = keys[pos];
					newRoot.keyTally = 1;
					Node<T>[] children = newRoot.getChildren();
					children[0] = curr;
					children[1] = righNode;
					newRoot.isLeaf = false;
					root = newRoot;
				} else {
					prev.righNode = righNode;
					prev.midkey = keys[pos];
				}

			} else {
				Comparable<T>[] currKeys = curr.getKeys();
				int currKeysIndex = curr.keyTally;
				for (; currKeysIndex > 0; currKeysIndex--) {
					if (currKeys[currKeysIndex - 1].equals(data)) {
						return;
					} else if (currKeys[currKeysIndex - 1].compareTo(data) > 0) {
						currKeys[currKeysIndex] = currKeys[currKeysIndex - 1];
					} else {
						break;
					}
				}

				currKeys[currKeysIndex] = data;
				curr.keyTally++;
			}
		} else {
			Comparable<T>[] currKeys = curr.getKeys();
			for (int currKeysIndex = 0; currKeysIndex < curr.keyTally; currKeysIndex++) {
				if (currKeys[currKeysIndex].equals(data)) {
					break;
				} else if (currKeys[currKeysIndex].compareTo(data) > 0) {
					insert(data, curr.getChildren()[currKeysIndex], curr);
					break;
				} else {
					if (currKeysIndex + 1 == curr.keyTally) {
						insert(data, curr.getChildren()[currKeysIndex + 1], curr);
						break;
					}
				}
			}
		}

		if (curr.righNode != null) {
			if (curr.keyTally == m - 1) {
				Comparable<T>[] keys = new Comparable[m];
				Comparable<T>[] currKeys = curr.getKeys();

				Node<T>[] children = new Node[m + 1];
				Node<T>[] currchildren = curr.getChildren();

				int keysArrIndex = m - 1;

				while (keysArrIndex > 0) {
					Comparable<T> temp = currKeys[keysArrIndex - 1];
					if (temp.equals(curr.midkey)) {
						return;
					} else if (temp.compareTo((T) curr.midkey) < 0) {
						break;
					} else {
						keys[keysArrIndex] = temp;
					}
					keysArrIndex--;
				}

				keys[keysArrIndex] = curr.midkey;

				keysArrIndex--;

				while (keysArrIndex >= 0) {
					Comparable<T> temp = currKeys[keysArrIndex];
					keys[keysArrIndex] = temp;
					keysArrIndex--;
				}

				int childrenArrIndex = m;

				while (childrenArrIndex > 0) {
					Node<T> tempNode = currchildren[childrenArrIndex - 1];
					if (tempNode.getKeys()[0].compareTo((T) curr.midkey) < 0) {
						break;
					} else {
						children[childrenArrIndex] = tempNode;
					}
					childrenArrIndex--;
				}

				children[childrenArrIndex] = curr.righNode;
				childrenArrIndex--;

				while (childrenArrIndex >= 0) {
					children[childrenArrIndex] = currchildren[childrenArrIndex];
					childrenArrIndex--;
				}

				int pos = (int) Math.floor((m - 1) / (double) 2);

				Node<T> righNode = new Node<T>(m);
				righNode.isLeaf = false;
				Comparable<T>[] rightNodeKeys = righNode.getKeys();
				Node<T>[] rightNodechildren = righNode.getChildren();

				for (int currKeysIndex = 0; currKeysIndex < currKeys.length; currKeysIndex++) {
					if (currKeysIndex < pos) {
						currKeys[currKeysIndex] = keys[currKeysIndex];
					} else {
						currKeys[currKeysIndex] = null;
						curr.keyTally--;
					}
				}

				for (int rightNodeKeysIndex = 0, posTemp = pos + 1; posTemp < m; posTemp++, rightNodeKeysIndex++) {
					rightNodeKeys[rightNodeKeysIndex] = keys[posTemp];
					righNode.keyTally++;
				}

				for (int currchildrenIndex = 0; currchildrenIndex < m; currchildrenIndex++) {
					if (currchildrenIndex <= pos) {
						currchildren[currchildrenIndex] = children[currchildrenIndex];
					} else {
						currchildren[currchildrenIndex] = null;
					}
				}

				for (int rightNodechildrenIndex = 0,
						posTemp = pos + 1; posTemp <= m; posTemp++, rightNodechildrenIndex++) {
					rightNodechildren[rightNodechildrenIndex] = children[posTemp];
				}

				if (prev == null) {
					Node<T> newRoot = new Node<T>(m);
					Comparable<T>[] newRootkeys = newRoot.getKeys();
					newRootkeys[0] = keys[pos];
					newRoot.keyTally = 1;
					Node<T>[] childrenNode = newRoot.getChildren();
					childrenNode[0] = curr;
					childrenNode[1] = righNode;
					newRoot.isLeaf = false;
					root = newRoot;
				} else {
					prev.righNode = righNode;
					prev.midkey = keys[pos];
				}

			} else {
				int currKeysIndex = curr.keyTally;
				Comparable<T>[] currKeys = curr.getKeys();
				Node<T>[] currchildren = curr.getChildren();
				for (; currKeysIndex > 0; currKeysIndex--) {
					if (currKeys[currKeysIndex - 1].compareTo((T) curr.midkey) < 0) {
						break;
					} else {
						currKeys[currKeysIndex] = currKeys[currKeysIndex - 1];
					}
				}

				currKeys[currKeysIndex] = curr.midkey;
				int pos = currKeysIndex + 1;
				curr.keyTally++;

				for (int currchildrenIndex = m - 1; currchildrenIndex > pos; currchildrenIndex--) {
					currchildren[currchildrenIndex] = currchildren[currchildrenIndex - 1];
				}
				currchildren[pos] = curr.righNode;

			}
			curr.righNode = null;
			curr.midkey = null;
		}
	}

	private int countNumNodes(Node<T> curr) {
		int numNodes = 1;
		if (curr.isLeaf == false) {
			for (int currKeysIndex = 0; currKeysIndex <= curr.keyTally; currKeysIndex++) {
				numNodes += countNumNodes(curr.getChildren()[currKeysIndex]);
			}
		}

		return numNodes;
	}

	private int numKeys(Node<T> curr) {
		int numKeys = curr.keyTally;

		if (curr.isLeaf == false) {

			for (int currKeysIndex = 0; currKeysIndex <= curr.keyTally; currKeysIndex++) {
				numKeys += numKeys(curr.getChildren()[currKeysIndex]);
			}
		}

		return numKeys;
	}

	private void nodes(Node<T> curr, Node<T>[] currNodes) {
		for (int currNodesArrIndex = 0; currNodesArrIndex < currNodes.length; currNodesArrIndex++) {
			if (currNodes[currNodesArrIndex] == null) {
				currNodes[currNodesArrIndex] = curr;
				break;
			}
		}

		if (curr.isLeaf == false) {
			for (int currKeysIndex = 0; currKeysIndex <= curr.keyTally; currKeysIndex++) {
				nodes(curr.getChildren()[currKeysIndex], currNodes);
			}
		}
	}

}