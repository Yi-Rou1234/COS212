public class MirroredBinaryTree<T extends Comparable<T>> extends BinaryTree<T> {
    @Override
    public boolean contains(T data) {
        //TODO: Implement this function
        return contains(root,data);
    }

    @Override
    public void depthFirstTraversal() {
        //TODO: Implement this function
        if (root == null){
            return;
        }
        depthFirstTraversal(root);
    }

    @Override
    public int numLeavesInTree() {
        //TODO: Implement this function
        return numLeavesInTree(root);
    }

    @Override
    public int height() {
        //TODO: Implement this function
        if (root == null){
            return 0;
        }
        else 
        return height(root);
    }

    @Override
    public Leaf<T> findParent(T data) {
        //TODO: Implement this function
        return findParent(root, data) ;
    }

    @Override
    public void insert(T data) {
        super.insert(data, false);
    }

    @Override
    public Leaf<T> find(T data) {
        //TODO: Implement this function
        return find(root,data);
    }

    @Override
    public boolean perfectlyBalanced() {
        //TODO: Implement this function
        return perfectlyBalanced(root);
    }

    @Override
    public BinaryTree<T> convertTree() {
        //TODO: Implement this function
        BinaryTree<T> newTree = new StandardBinaryTree<>();
        convertTree(root, newTree);
        return newTree;
    }

    private void depthFirstTraversal(Leaf<T> root){
        if (root == null){
            return;
        }
        
        depthFirstTraversal(root.right);
        System.out.println(root.toString());
        depthFirstTraversal(root.left);
    }

    private int height(Leaf<T> root){
        if (root == null){
            return -1;
        }

        int Left = height(root.left);
        int Right = height(root.right);

        if (Left > Right){
            return Left +1;
        }
        else {
            return Right +1;
        }
    }

    private int numLeavesInTree(Leaf<T> root){
        if (root == null){
            return 0;
        }
        else {
            return 1 + numLeavesInTree(root.left) + numLeavesInTree(root.right);
        }
    }

    private boolean perfectlyBalanced(Leaf<T> root){
        if (root == null){
            return true;
        }
        Leaf<T> leftRoot = root.left;
        Leaf<T> rightRoot = root.right;

        int LeftLeaf = numLeavesInTree(leftRoot);
        int RightLeaf = numLeavesInTree(rightRoot);
        
        if (LeftLeaf == RightLeaf){
            return true;
        }
        else {
            return false;
        }
    }

    private Leaf<T> findParent(Leaf<T> curr, T data){
        if (curr == null) 
        return null;

        System.out.println(curr.toString());
        if (curr.left != null){
            if (curr.left.data.equals(data)) {
                return curr;
            }
            if (data.compareTo(curr.data) > 0){
                return findParent(curr.left, data);
            }
        }
        if (curr.right != null){
            if (curr.right.data.equals(data)) {
                return curr;
            }
            if (data.compareTo(curr.data) < 0){
                return findParent(curr.right, data);
            }
        }
        return null;
    }

    private Leaf<T> find(Leaf<T> current, T data){
        if(current == null){
            return null;
        }
        System.out.println(current.toString());

        if (current.data.compareTo(data) == 0 ){
            return current;
        }
        if (data.compareTo(current.data) > 0){
            return find(current.left, data);
        }
        else {
            // current.toString();
            return find(current.right, data);
        }
    }

    private boolean contains(Leaf<T> current, T data){
        if ( current == null){
            return false;
        }
        System.out.println(current.toString());
        if (current.data.compareTo(data) == 0){
            return true;
        }
        
        if (data.compareTo(current.data) > 0){
            // current.toString();
            find(current.left, data);
        }
        else {
            // current.toString();
            find(current.right, data);
        }
        // if (current.data.compareTo(data) != 0)
        // System.out.println(current.toString());
        return false;
    }

    private BinaryTree<T> convertTree(Leaf<T> curr , BinaryTree<T> newTree){
        if (curr == null){
            return null;
        }
        newTree.insert(curr.data);
        convertTree(curr.left, newTree);
        convertTree(curr.right, newTree);

        return newTree;
    }
}
